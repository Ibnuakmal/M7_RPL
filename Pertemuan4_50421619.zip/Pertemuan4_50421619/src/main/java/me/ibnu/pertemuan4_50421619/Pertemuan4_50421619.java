/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package me.ibnu.pertemuan4_50421619;

/**
 *
 * @author ASUS
 */
public class Pertemuan4_50421619 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
